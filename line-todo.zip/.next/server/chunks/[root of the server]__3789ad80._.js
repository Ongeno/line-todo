module.exports = {

"[project]/.next-internal/server/app/api/timeline-settings/route/actions.js [app-rsc] (server actions loader, ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
}}),
"[externals]/next/dist/compiled/next-server/app-route.runtime.dev.js [external] (next/dist/compiled/next-server/app-route.runtime.dev.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}}),
"[externals]/next/dist/compiled/next-server/app-page.runtime.dev.js [external] (next/dist/compiled/next-server/app-page.runtime.dev.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/better-sqlite3 [external] (better-sqlite3, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("better-sqlite3", () => require("better-sqlite3"));

module.exports = mod;
}}),
"[externals]/path [external] (path, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("path", () => require("path"));

module.exports = mod;
}}),
"[project]/src/lib/db.ts [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$better$2d$sqlite3__$5b$external$5d$__$28$better$2d$sqlite3$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/better-sqlite3 [external] (better-sqlite3, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/path [external] (path, cjs)");
;
;
// 创建数据库连接
const db = new __TURBOPACK__imported__module__$5b$externals$5d2f$better$2d$sqlite3__$5b$external$5d$__$28$better$2d$sqlite3$2c$__cjs$29$__["default"](__TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].join(process.cwd(), 'timeline.db'));
// 检查是否需要添加titleOffset列
const checkAndAddTitleOffsetColumn = ()=>{
    // 检查nodes表中是否已经有titleOffset列
    const columns = db.prepare("PRAGMA table_info(nodes)").all();
    const hasTitleOffset = columns.some((column)=>column.name === 'titleOffset');
    // 如果没有titleOffset列，添加它
    if (!hasTitleOffset) {
        db.prepare("ALTER TABLE nodes ADD COLUMN titleOffset TEXT").run();
        console.log("Added titleOffset column to nodes table");
    }
};
// 初始化数据库表
db.exec(`
  CREATE TABLE IF NOT EXISTS nodes (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    date TEXT NOT NULL,
    type TEXT NOT NULL,
    description TEXT,
    titleOffset TEXT
  );

  CREATE TABLE IF NOT EXISTS todos (
    id TEXT PRIMARY KEY,
    nodeId TEXT NOT NULL,
    text TEXT NOT NULL,
    completed BOOLEAN NOT NULL DEFAULT 0,
    FOREIGN KEY (nodeId) REFERENCES nodes(id)
  );
  
  CREATE TABLE IF NOT EXISTS timeline_settings (
    id TEXT PRIMARY KEY DEFAULT 'default',
    startDate TEXT NOT NULL,
    endDate TEXT NOT NULL
  );
`);
// 检查并添加新列（对于已有的数据库）
checkAndAddTitleOffsetColumn();
const __TURBOPACK__default__export__ = db;
}}),
"[project]/src/lib/dbOperations.ts [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "dbOperations": (()=>dbOperations)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
;
const dbOperations = {
    // 节点操作
    getAllNodes: ()=>{
        const nodes = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].prepare('SELECT * FROM nodes').all();
        const nodesWithTodos = nodes.map((node)=>{
            // 如果数据库中有titleOffset字段，解析JSON字符串
            if (node.titleOffset && typeof node.titleOffset === 'string') {
                try {
                    node.titleOffset = JSON.parse(node.titleOffset);
                } catch (e) {
                    console.error('Failed to parse titleOffset:', e);
                    node.titleOffset = {
                        x: 0,
                        y: 0
                    };
                }
            } else {
                node.titleOffset = {
                    x: 0,
                    y: 0
                };
            }
            return {
                ...node,
                todos: dbOperations.getTodosByNodeId(node.id)
            };
        });
        return nodesWithTodos;
    },
    getNodeById: (id)=>{
        const node = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].prepare('SELECT * FROM nodes WHERE id = ?').get(id);
        if (node) {
            // 如果数据库中有titleOffset字段，解析JSON字符串
            if (node.titleOffset && typeof node.titleOffset === 'string') {
                try {
                    node.titleOffset = JSON.parse(node.titleOffset);
                } catch (e) {
                    console.error('Failed to parse titleOffset:', e);
                    node.titleOffset = {
                        x: 0,
                        y: 0
                    };
                }
            } else {
                node.titleOffset = {
                    x: 0,
                    y: 0
                };
            }
            node.todos = dbOperations.getTodosByNodeId(id);
        }
        return node;
    },
    createNode: (node)=>{
        const { id, title, date, type, description, titleOffset } = node;
        // 将titleOffset转换为JSON字符串
        const titleOffsetStr = titleOffset ? JSON.stringify(titleOffset) : JSON.stringify({
            x: 0,
            y: 0
        });
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].prepare('INSERT INTO nodes (id, title, date, type, description, titleOffset) VALUES (?, ?, ?, ?, ?, ?)').run(id, title, date, type, description, titleOffsetStr);
        // 创建关联的待办事项
        node.todos.forEach((todo)=>{
            dbOperations.createTodo(todo);
        });
        return node;
    },
    updateNode: (node)=>{
        const { id, title, date, type, description, titleOffset } = node;
        // 将titleOffset转换为JSON字符串
        const titleOffsetStr = titleOffset ? JSON.stringify(titleOffset) : JSON.stringify({
            x: 0,
            y: 0
        });
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].prepare('UPDATE nodes SET title = ?, date = ?, type = ?, description = ?, titleOffset = ? WHERE id = ?').run(title, date, type, description, titleOffsetStr, id);
        // 更新待办事项
        const existingTodos = dbOperations.getTodosByNodeId(id);
        const todosToDelete = existingTodos.filter((existingTodo)=>!node.todos.find((todo)=>todo.id === existingTodo.id));
        const todosToCreateOrUpdate = node.todos;
        // 删除不再存在的待办事项
        todosToDelete.forEach((todo)=>{
            dbOperations.deleteTodo(todo.id);
        });
        // 创建或更新待办事项
        todosToCreateOrUpdate.forEach((todo)=>{
            const exists = existingTodos.find((t)=>t.id === todo.id);
            if (exists) {
                dbOperations.updateTodo(todo);
            } else {
                dbOperations.createTodo(todo);
            }
        });
        return node;
    },
    deleteNode: (id)=>{
        // 首先删除关联的待办事项
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].prepare('DELETE FROM todos WHERE nodeId = ?').run(id);
        // 然后删除节点
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].prepare('DELETE FROM nodes WHERE id = ?').run(id);
    },
    // 待办事项操作
    getTodosByNodeId: (nodeId)=>{
        try {
            const todos = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].prepare('SELECT * FROM todos WHERE nodeId = ?').all(nodeId);
            return todos.map((todo)=>({
                    ...todo,
                    completed: Boolean(todo.completed)
                }));
        } catch (error) {
            console.error('Failed to get todos:', error);
            return [];
        }
    },
    createTodo: (todo)=>{
        try {
            const { id, nodeId, text, completed } = todo;
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].prepare('INSERT INTO todos (id, nodeId, text, completed) VALUES (?, ?, ?, ?)').run(id, nodeId, text, completed ? 1 : 0);
            return {
                ...todo,
                completed: Boolean(completed)
            };
        } catch (error) {
            console.error('Failed to create todo:', error);
            throw error;
        }
    },
    updateTodo: (todo)=>{
        try {
            const { id, text, completed } = todo;
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].prepare('UPDATE todos SET text = ?, completed = ? WHERE id = ?').run(text, completed ? 1 : 0, id);
            return {
                ...todo,
                completed: Boolean(completed)
            };
        } catch (error) {
            console.error('Failed to update todo:', error);
            throw error;
        }
    },
    deleteTodo: (id)=>{
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].prepare('DELETE FROM todos WHERE id = ?').run(id);
    },
    // 时间轴设置操作
    getTimelineSettings: ()=>{
        const settings = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].prepare('SELECT * FROM timeline_settings WHERE id = ?').get('default');
        if (settings) {
            return {
                startDate: new Date(settings.startDate),
                endDate: new Date(settings.endDate)
            };
        }
        return null;
    },
    saveTimelineSettings: (startDate, endDate)=>{
        // 检查是否已有设置
        const exists = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].prepare('SELECT * FROM timeline_settings WHERE id = ?').get('default');
        if (exists) {
            // 更新设置
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].prepare('UPDATE timeline_settings SET startDate = ?, endDate = ? WHERE id = ?').run(startDate.toISOString(), endDate.toISOString(), 'default');
        } else {
            // 插入新设置
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].prepare('INSERT INTO timeline_settings (id, startDate, endDate) VALUES (?, ?, ?)').run('default', startDate.toISOString(), endDate.toISOString());
        }
        return {
            startDate,
            endDate
        };
    }
};
}}),
"[project]/src/app/api/timeline-settings/route.ts [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "GET": (()=>GET),
    "POST": (()=>POST)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$dbOperations$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/dbOperations.ts [app-route] (ecmascript)");
;
;
async function GET() {
    try {
        const settings = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$dbOperations$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["dbOperations"].getTimelineSettings();
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json(settings);
    } catch  {
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            error: 'Failed to fetch timeline settings'
        }, {
            status: 500
        });
    }
}
async function POST(request) {
    try {
        const { startDate, endDate } = await request.json();
        // 验证日期数据
        if (!startDate || !endDate) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                error: 'Start date and end date are required'
            }, {
                status: 400
            });
        }
        // 保存设置
        const savedSettings = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$dbOperations$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["dbOperations"].saveTimelineSettings(new Date(startDate), new Date(endDate));
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json(savedSettings);
    } catch  {
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            error: 'Failed to save timeline settings'
        }, {
            status: 500
        });
    }
}
}}),

};

//# sourceMappingURL=%5Broot%20of%20the%20server%5D__3789ad80._.js.map